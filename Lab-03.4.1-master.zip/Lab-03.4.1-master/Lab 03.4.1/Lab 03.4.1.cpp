﻿#include <iostream>
using namespace std;
int main()
{
    double x; // вхідний аргумент
    double y; // вхідний параметр
    double R; // вхідний параметр
    cout << "x = "; cin >> x;
    cout << "y = "; cin >> y;
    cout << "R = "; cin >> R;

    // розгалуження в повній формі
    
    if ((x + R) *(x + R) + (y - R) * (y - R) >= R * R
        && y >= 0 && y <= R && x >= -R && x <= 0 ||
        x * x + y * y <= R * R && x >= 0 && y <= 0)

        cout << "yes" << endl;
    else
        cout << "no" << endl;
    cin.get();
    return 0;
}