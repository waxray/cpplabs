﻿#include <iostream>
#include <iomanip>
#include <time.h>

using namespace std;

void MASS(int* a, const int n, int i)
{
    if (i < n)
    {
        a[i] = -20 + rand() % 34;
        return MASS(a, n, i + 1);
    }
}
template <typename T>
T MASS(T* a, const int n, int i)
{
    if (i < n)
    {
        a[i] =(T)(-20 + rand() % 34);
        return MASS<T>(a, n, i + 1);
    }
}

void Print(int* a, const int n, int i)
{
    if (i < n)
    {
        if (i == 0)

            cout << "{";
        cout << a[i];
        if (i != n - 1)
            cout << ", ";
        else cout << "}" << endl;
        return Print(a, n, i + 1);

    }
}
template <typename T>
T Print(T* a, const int n, int i)
{
    if (i < n)
    {
        if (i == 0)

            cout << "{";
        cout << a[i];
        if (i != n - 1)
            cout << ", ";
        else cout << "}" << endl;
        return Print<T>(a, n, i + 1);

    }
}



int Count(const int* a, const int n, int i)
{
    if (i < n)
    {
        if (a[i] % 2 == 0)
            return 1 + Count(a, n, i + 1);
        else
            return Count(a, n, i + 1);
    }
    else return 0;
}
template <typename T>
int Count(const T* a, const int n, int i)
{
    if (i < n)
    {
        if (a[i] % 2 == 0 )
            return 1 + Count(a, n, i + 1);
        else
            return Count<T>(a, n, i + 1);
    }
    else return 0;
}int main()
{
    int n;
    cout << "n = "; cin >> n;
    int* a = new int[n];
    MASS<int>(a, n, 0);
    Print<int>(a, n ,0);
    cout << "Count element by condition = " << Count<int>(a, n) << endl;
}