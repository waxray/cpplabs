﻿#include <iostream>
#include <iomanip>
#include <time.h>

using namespace std;

void Array(int* a, const int n)
{
    for (int i = 0; i < n; i++)
        a[i] = -50 + rand() % 100;
}



void Print(const int* const a, const int n)
{
    cout << "{";
    for (int i = 0; i < n; i++)
    {
        cout << a[i];
        if (i != n - 1)
            cout << ", ";
    }
    cout << "}" << endl;
}



int Count(const int* const a, const int n, const int C)
{
    int D = 0;
    for (int i = 0; i < n; i++)
        if (a[i] > C)
            D++;
    return D;
}

int Max(const int* const a, const int n)
{
    int index = 0;
    int max = a[0];
    for (int i = 1; i < n; i++)
        if (abs(a[i]) > abs(max))
        {
            max = a[i];
            index = i;
        }

    return index;
}

int product(const int* const a, const int n)
{
    int D = 1;
    for (int i = 0; i < n; i++)
    {
        if (i > Max(a, n))

            D *= a[i];
    }
    return D;
}
void Sort(int* a, const int n) // метод обміну (бульбашки)
{
    for (int i = 1; i < n; i++) // лічильник ітерацій
        for (int j = 0; j < n - i; j++) // номер поточного елемента
            if (a[j] > 0) // якщо порушено умову впорядкування
            { // - обмін елементів місцями
                int tmp = a[j];
                a[j] = a[j + 1];
                a[j + 1] = tmp;
            }
}
int main()
{

    int C;
    cout << "C ="; cin >> C;
    int n;
    cout << "n = "; cin >> n;
    int* a = new int[n];


    Array(a, n);
    Print(a, n);
    cout << "Max = " << Max(a, n) << endl;
    cout << "Product = " << product(a, n) << endl;
    cout << "Count element by condition = " << Count(a, n, C) << endl;
    Sort(a, n);
    cout << "Array after being sorted -"; Print(a, n);
}
