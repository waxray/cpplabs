﻿#include <iostream>

using namespace std;

int Sum(int num, int level, int& depth)

{
	if (level > depth)
		depth = level;

	if (num == 0)
		return 0;
	else
		return num % 10 + Sum(num / 10, level + 1, depth);
}
int Count(int num, int level, int& depth)
{
	if (level > depth)
		depth = level;
	if (num == 0)
		return 0;
	else
		return 1 + Count(num / 10, level + 1, depth);
}
int Max(int num, int level, int& depth)
{


	if (level > depth)
		depth = level;

	if (num % 10 == num)
		return num;
	else
		if (num % 10 > Max(num / 10, level + 1, depth))
			return num % 10;
		else
			return Max(num / 10, level + 1, depth);

}
int Min(int num, int level, int& depth)
{
	if (num % 10 == num)
		return num;
	else
		if (num % 10 < Min(num / 10, level + 1, depth))
			return num % 10;
		else
			return Min(num / 10, level + 1, depth);

}
int main()
{
	int num, depth;
	cout << "Num = "; cin >> num;

	cout << "Sum="; cout << Sum(num, 0, depth) << endl;
	cout << "Depth of Sum()="; cout << depth << endl;

	cout << "Max="; cout << Max(num, 0, depth) << endl;
	cout << "Depth of Max() = " << depth << endl;

	cout << "Min="; cout << Min(num, 0, depth) << endl;
	cout << "Depth of Min()="; cout << depth << endl;

	cout << "Count="; cout << Count(num, 0, depth) << endl;
	cout << "Depth of Count()="; cout << depth << endl;
	return 0;

}