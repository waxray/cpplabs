﻿#include <iostream>
#include <iomanip>
#include <time.h>

using namespace std;
void Create(int** a, const int rowCount, const int colCount, const int Low, const int High, int i, int j);
void Print(int** a, const int rowCount, const int colCount, int i, int j);
void exchange(int** a, const int colCount, int rowCount);
int Min(int** a, const int colCount, int rowCount);
int Max(int** a, const int colCount, int rowCount);

int main()
{
	srand((unsigned)time(NULL));
	int rowCount;
	int colCount;
	int Low = 7;
	int High = 65;
	cout << "rowCount = "; cin >> rowCount;
	cout << "colCount = "; cin >> colCount;

	int** a = new int* [rowCount];
	for (int i = 0; i < rowCount; i++)
		a[i] = new int[colCount];
	Create(a, rowCount, colCount, Low, High, 0, 0);
	cout << "--------------------" << endl;
	Print(a, rowCount, colCount, 0, 0);
	cout << "--------------------" << endl;
	exchange(a, colCount, rowCount);
	Print(a, rowCount, colCount, 0, 0);
	cout << "--------------------" << endl;

	return 0;
}
void exchange(int** a, const int rowCount, int colCount_i) {
	if (colCount_i % 2 == 0)
		--colCount_i;
	else colCount_i -= 2;

	int min = Min(a, colCount_i, rowCount);
	int max = Max(a, colCount_i, rowCount);

	int tmp = a[colCount_i][max];
	a[colCount_i][max] = a[colCount_i][min];
	a[colCount_i][min] = tmp;


	if (colCount_i > 1)
		exchange(a, rowCount, colCount_i);
}






void Create(int** a, const int rowCount, const int colCount, const int Low, const int High, int i, int j)
{
	a[i][j] = Low + rand() % (High - Low + 1);

	j++;
	if (j == colCount) {
		i++;
		j = 0;
	}

	if (i < rowCount)
		Create(a, rowCount, colCount, Low, High, i, j);
}

void Print(int** a, const int rowCount, const int colCount, int i, int j)
{
	cout << setw(4) << a[i][j];

	j++;
	if (j == colCount) {
		i++;
		j = 0;
		cout << endl;
	}

	if (i == rowCount)
		return;
	Print(a, rowCount, colCount, i, j);
}


int Min(int** a, const int rowCount, int colCount)
{
	if (colCount > 1) {
		int min = Min(a, rowCount, colCount - 1);
		if (a[rowCount][min] > a[rowCount][colCount - 1])
			min = colCount - 1;
		return min;
	}
	return 0;
}

int Max(int** a, const int rowCount, int  colCount)
{
	if (colCount > 1) {
		int min = Max(a, rowCount, colCount - 1);
		if (a[rowCount][min] < a[rowCount][colCount - 1])
			min = colCount - 1;
		return min;
	}
	return 0;
}
