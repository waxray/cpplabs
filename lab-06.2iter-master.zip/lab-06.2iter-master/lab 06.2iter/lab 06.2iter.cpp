﻿#include <iostream>
#include <iomanip>
#include <time.h>

using namespace std;

void MASS(int* a, const int n, int x, int y)
{
    for (int i = 0; i < n; i++)
        a[i] = x + rand() % (x - y + 1);
}

void Print(const int* const a, const int n)
{
    cout << "{";
    for (int i = 0; i < n; i++)
    {
        cout << a[i];
        if (i != n - 1)
            cout << ", ";
    }
    cout << "}" << endl;
}


int Max(int* a, const int size)
{
    int max = a[0];
    for (int i = 1; i < size; i++)
        if (a[i] > max)
            max = a[i];
    return max;
}

int Min(int* a, const int size)
{
    int min = a[0];
    for (int i = 1; i < size; i++)
        if (a[i] < min)
            min = a[i];
    return min;
}


int main()
{
    srand((unsigned)time(NULL));
    int n;
    cout << "n = "; cin >> n;

    int* a = new int[n];
    int x, y;
    cout << "x="; cin >> x;
    cout << "y="; cin >> y;
    MASS(a, n, x, y);
    Print(a, n);

    int result = Max(a, n) + Min(a, n);
    cout << "Result=" << result << endl;
}
