﻿#include <math.h>
#include <iostream>

using namespace std;

int main()
{
    float x, y, R1, R2, xp, xk;
    cout << "xp= "; cin >> xp;
    cout << "xk= "; cin >> xk;
    cout << "R1= "; cin >> R1;
    cout << "R2= "; cin >> R2;
    x = xp;

    while (x < xk) {
        if (x <= -6) {
            y = R2 / 2;
        }
        else {
            if (x <= -2*R2) {
                y = (R2*R2 - x) / (-6 + 2 * R2);
            }
            else {
                if (x <= 0) {
                    y = sqrt(-(x*x)-2*x*R2);
                }
                else {
                    if (x <= 2*R1) {
                        y = sqrt(-(x*x)+2*x*R1);
                    }
                    else {
                        y = -R1*x + 2 * R1 * R1;
                    }
                }
            }

        }
        cout << "x=" << x << "\t" << "y=" << y << endl;
        x += 1;
    }

    return 0;
}