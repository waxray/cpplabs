﻿#include <iostream>
#include <iomanip>
#include <time.h>

using namespace std;

void MASS(int* a, const int n)
{
    for (int i = 0; i < n; i++)
        a[i] = -50 + rand() % 100;
}
template <typename T>
void MASS(T* a, const int n)
{
    for (int i = 0; i < n; i++)
        a[i] = (T)(-50 + rand() % 100);
}


void Print(const int* const a, const int n)
{
    cout << "{";
    for (int i = 0; i < n; i++)
    {
        cout << a[i];
        if (i != n - 1)
            cout << ", ";
    }
    cout << "}" << endl;
}
template <typename T>
void Print(const T* const a, const int n)
{
    cout << "{";
    for (int i = 0; i < n; i++)
    {
        cout << a[i];
        if (i != n - 1)
            cout << ", ";
    }         cout << "}" << endl;
}


int Count(const int* const a, const int n)
{
    int D = 0;
    for (int i = 0; i < n; i++)
        if (a[i] % 2 == 0)
            D++;
    return D;
}
template <typename T>

int Count(const T* const a, const int n)
{
    int D = 0;
    for (int i = 0; i < n; i++)
        if (a[i] % 2 == 0)
            D++;
    return D;
}
int main()
{
    int n;
    cout << "n = "; cin >> n;
    int* a = new int[n];

    MASS<int>(a, n);
    Print<int>(a, n);
    cout << "Count element by condition = " << Count<int>(a, n) << endl;
}

