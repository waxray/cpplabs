﻿#include <iostream>
#include <iomanip>
#include <time.h>

using namespace std;

void Array(int* a, const int n, int i)
{
    if (i < n)
    {
        a[i] = -50 + rand() % 100;
        return Array(a, n, i + 1);
    }
}



void Print(const int* const a, const int n, int i)
{
    if (i < n)
    {
        if (i == 0)
            cout << "{";
        cout << a[i];
        if (i != n - 1)
            cout << ",";
        else cout << "}" << endl;
        return Print(a, n, i + 1);
    }
}



int Count(const int* a, const int n, int C, int i)
{
    if (i < n)
    {
        if (a[i] > C)
            return 1 + Count(a, n, C, i + 1);
        else
            return Count(a, n, C, i + 1);
    }
    else return 0;
}
void Max(int* a, const int n, int i, int max, int& index)
{
    if (i < n) {
        if (abs(a[i]) > abs(max))
        {
            max = a[i];
            index = i;
        }
        Max(a, n, i + 1, max, index);
    }
}
int Prod(int* a, const int n, int i)
{
    if (i < n)
        return a[i] * Prod(a, n, i + 1);
    else
        return 1;
}
void Sort(int* a, const int n, int i, int j, int& k)
{
    if (a[j] > 0)
    {
        int tmp = a[j];
        a[j] = a[j + 1];
        a[j + 1] = tmp;
        k = 1;
    }
    if (j < n - i - 1)
        Sort(a, n, i, j + 1, k);
    if (k == 0)
        return;
    if (i < n - 1)
    {
        k = 0;
        Sort(a, n, i + 1, 0, k);
    }
}
int main()
{
    srand((unsigned)time(NULL));
    int C;
    cout << "C = "; cin >> C;
    int n;
    cout << "n = "; cin >> n;
    int* a = new int[n];


    Array(a, n, 0);
    Print(a, n, 0);
    cout << "Count element by condition = " << Count(a, n, C, 0) << endl;
    int index = 0;
    Max(a, n, 0, a[0], index);
    cout << "Max = " << index << endl;
    cout << "Product = " << Prod(a, n, index + 1) << endl;

    int k = 0;
    Sort(a, n, 1, 0, k);
    cout << "Array after being sorted -"; Print(a, n, 0);
}
