﻿#include <iostream> 
#include <iomanip> 
#include <time.h> 
using namespace std;
void ARR(int* a, const int size, int i)
{
    if (i < size)
    {
        a[i] = -20 + rand() % 34;
        return ARR(a, size, i + 1);
    }
}

void in(int* a, const int size, int i)
{
    if (i < size)
    {
        if (i == 0)

            cout << "{";
        cout << a[i];
        if (i != size - 1)
            cout << ", ";
        else cout << "}" << endl;
        return in(a, size, i + 1);

    }
}

int Sum(const int* const a, const int size, int i)
{
    if (i < size)
    {
        if (a[i] % 2 != 0 || a[i] < 0)
            return  a[i] + Sum(a, size, i + 1);
        else
            return Sum(a, size, i + 1);
    }
    else return 0;
}

int out(const int* a, const int size, int i)
{
    if (i < size)
    {
        if (a[i] % 2 != 0 || a[i] < 0)
            return 1 + out(a, size, i + 1);
        else
            return out(a, size, i + 1);
    }
    else return 0;
}
void GOT(int a[], const int size, int i)
{
    if (i < size)
    {
        if (a[i] % 2 != 0 || a[i] < 0)
            a[i] = 0;
        return GOT(a, size, i + 1);
    }
}

int main()
{
    srand((unsigned)time(NULL));
    const int size = 20;
    int a[size];
    ARR(a, size, 0);
    in(a, size, 0);
    cout << "The sum of the elements that satisfy the condition = " << Sum(a, size, 0) << endl;
    cout << "The number of elements that satisfy the condition = " << out(a, size, 0) << endl;
    GOT(a, size, 0);
    in(a, size, 0);
    out(a, size, 0);
    return 0;
}
