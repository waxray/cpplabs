﻿#include <iostream>
#include <iomanip>
#include <time.h>

using namespace std;

void MASS(int a[], const int n, int i)
{
    if (i < n)
    {
        a[i] = -50 + rand() % 100;
        MASS(a, n, i + 1);
    }
}

void Print(const int* const a, const int n, int i)
{
    if (i < n)
    {
        if (i == 0)
            cout << "{";
        cout << a[i];
        if (i != n - 1)
            cout << ", ";
        else cout << "}" << endl;
        Print(a, n, i + 1);
        return;
    }
}


int Max(int* a, const int n, int i, int max)
{
    if (a[i] > max)
        max = a[i];
    if (i < n - 1)
        return Max(a, n, i + 1, max);
    else
        return max;
}


int Min(int* a, const int n, int i, int min)
{
    if (a[i] < min)
        min = a[i];
    if (i < n - 1)
        return Min(a, n, i + 1, min);
    else
        return min;
}


int main()
{
    srand((unsigned)time(NULL));



    const int n = 20;
    int a[n];


    MASS(a, n, 0);

    cout << fixed;
    cout << "===============================================================================" << endl;
    cout << "|" << a[0];
    for (int i = 1; i < sizeof a / sizeof(int);) cout << setw(2) << " " << a[i++];
    cout << "|" << endl;
    cout << "===============================================================================" << endl;


    int max = Max(a, n, 0, 0);
    cout << "| " << "max = " << max << "|" << endl;

    int min = Min(a, n, 0, n - 1);
    cout << "| " << "min = " << setw(2) << min << setw(6) << " |" << endl;
    int Result = min + max;


    cout << "===============================================================================" << endl;
    cout << "|" << endl;
    cout << "Result =" << Result << endl;

    cout << "|" << endl;
    cout << "===============================================================================" << endl;

}

