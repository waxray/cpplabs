﻿#include <iostream>

using namespace std;

double get_factorial(double x) {
    double factorial = 1.0;
    for (int i = 1; i <= x; ++i) {
        factorial *= i;
    }
    return factorial;
}

double function(double x)
{
    if (abs(x) >= 1) {
        return (cos(2 * x) + 1) / (cos(x) + pow(sin(x), 2));
    }
    else {
        double res = 0;
        for (int k = 0; k < 6; k++) {
            res += (pow(2, 2 * k + 1) * pow(x, 2 * k + 1)) / get_factorial(2 * k + 1);
        }
        return res;
    }
}

int main()
{
    setlocale(LC_CTYPE, "ukr");

    int n;
    double P1, P2;

    cout << "Введiть N: ";
    cin >> n;

    cout << "Введiть Pпоч: ";
    cin >> P1;

    cout << "Введiть Pкiн: ";
    cin >> P2;

    for (double i = P1; i <= P2; i += (P2 - P1) / n) {
        double x = function(pow(i, 2)) + 2 * function(2 * i * pow(i, 2)) + 1;
        cout << "P = " << i << ", значення виразу: " << x << endl;
    }
}