﻿#include <iostream>
#include <iomanip>
#include <time.h>

using namespace std;
void Input(int** a, const int rowCount, const int colCount);
void Print(int** a, const int rowCount, const int colCount);
bool FindZero(int** a, const int rowCount, const int colCount, int& count);
int SumRow(int** a, const int n, const int colCount);
void Change(int** a, const int row1, const int row2, const int colCount);
void Sort(int** a, const int rowCount, const int colCount);

int main()
{
	int rowCount, colCount;
	cout << "rowCount = "; cin >> rowCount;
	cout << "colCount = "; cin >> colCount;
	int** a = new int* [rowCount];
	for (int i = 0; i < rowCount; i++)
		a[i] = new int[colCount];

	Input(a, rowCount, colCount);
	Print(a, rowCount, colCount);
	int number = 0;
	if (FindZero(a, rowCount, colCount, number))
		cout << "number = " << number << endl;
	else
		cout << "there are no zero elements" << endl;
	cout << endl;
	Sort(a, rowCount, colCount);
	Print(a, rowCount, colCount);
	for (int i = 0; i < rowCount; i++)
		delete[] a[i];
	delete[] a;
	return 0;
}

void Input(int** a, const int rowCount, const int colCount)
{

	for (int i = 0; i < rowCount; i++)
	{
		for (int j = 0; j < colCount; j++)
		{
			cout << "a[" << i << "][" << j << "] = ";
			cin >> a[i][j];
		}
		cout << endl;
	}
}
void Print(int** a, const int rowCount, const int colCount)
{
	cout << endl;
	for (int i = 0; i < rowCount; i++)
	{
		for (int j = 0; j < colCount; j++)
			cout << setw(4) << a[i][j];
		cout << endl;
	}
	cout << endl;
}
bool FindZero(int** a, const int rowCount, const int colCount, int& number)
{
	bool result = false;
	number = 0;
	int k_zero;
	for (int j = 0; j < colCount; j++)
	{
		k_zero = 0;
		for (int i = 0; i < rowCount; i++)
			if (a[i][j] == 0)
			{
				result = true;
				number = j;
				k_zero++;
				return number;
				break;
			}

	}
	return result;
}
int SumRow(int** a, const int n, const int colCount)
{
	int S = 0;
	for (int j = 0; j < colCount; j++)
	{
		if (a[n][j] < 0 && a[n][j] % 2 == 0)
			S += a[n][j];


	}
	return S;
}

void Change(int** a, const int row1, const int row2, const int colCount)
{
	int tmp;
	for (int j = 0; j < colCount; j++)
	{
		tmp = a[row1][j];
		a[row1][j] = a[row2][j];
		a[row2][j] = tmp;
	}
}
void Sort(int** a, const int rowCount, const int colCount)
{
	for (size_t i = 1; i < rowCount; i++)

		for (int j = 0; j < rowCount - i; j++)
			if (SumRow(a, j, colCount) < SumRow(a, j + 1, colCount))
			{
				Change(a, j, j + 1, colCount);
			}


}