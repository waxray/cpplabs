﻿#include <iostream>
#include <iomanip>
using namespace std;

void ADD(int a[], const int n)
{
	for (int i = 0; i < n; i++)
		a[i] = -20 + rand() % 34;
}

void in(int a[], const int n)
{
	cout << "{";
	for (int i = 0; i < n; i++)
	{
		cout << a[i];
		if (i != n - 1)
			cout << ", ";
	}
	cout << "}" << endl;
}


int Count(const int* const a, const int n)
{
	int D = 0;
	for (size_t i = 0; i < n; i++)
		if (a[i] < 0 && a[i] % 2 == 0)
			D++;
	return D;
}


int Sum(const int* const a, const int n)
{
	int S = 0;
	for (int i = 0; i < n; i++)
	{
		if (a[i] < 0 && a[i] % 2 == 0)
			S += a[i];
	}
	return S;
}
void Replace(int a[], const int n)
{
	for (int l = 0; l < n; l++)
	{
		if (a[l] < 0 && a[l] % 2 == 0)
			a[l] = 0;
	}
}

int main()
{
	srand(time(0));

	const int n = 20;
	int a[n];

	ADD(a, n);
	in(a, n);
	cout << "Array sum by condition = " << Sum(a, n) << endl;
	cout << "Count element by condition = " << Count(a, n) << endl;
	Replace(a, n);
	in(a, n);

	return 0;
}