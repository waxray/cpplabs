﻿#include <iostream>
#include <iomanip>
#include <time.h>
#include <math.h>
using namespace std;
int main()
{
    double x, y, R;
    cout << "R="; cin >> R;
    srand((unsigned)time(NULL));

    for (int i = 0; i < 10; i++)
    {
        x = 6. * rand() / RAND_MAX - 3;
        y = 6. * rand() / RAND_MAX - 3;
        if ((y >= sqrt(-x * x - 2 * x * R - R * R + 2 * y * R) && y >= 0 && y <= R && x >= -R && x <= 0) || (y <= sqrt((R * R) - (x * x))) && y <= 0 && x >= 0)
        {
            cout << setw(8) << setprecision(4) << x << " " << setw(8) << setprecision(4) << y << " " << "yes" << endl;
        }
        else {
            cout << setw(8) << setprecision(4) << x << " "
                << setw(8) << setprecision(4) << y << " " << "no" << endl;
        }
    }
    return 0;
}