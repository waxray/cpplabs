﻿// Lab_03_3.cpp
// < Маньянов Максим Юрійович >
// Лабораторна робота No 3.3
// Розгалуження, задане графіком функції.
// Варіант 15

#include <iostream>
#include <cmath>
#include <math.h>
using namespace std;
int main()
{
	double x;
	double y;
	double R1;
	double R2;

	cout << "R1 = "; cin >> R1;
	cout << "R2 = "; cin >> R2;
	cout << "x = "; cin >> x;

	if (x <= -6)
	{
		y = R2 / 2;
	}
	else if (x > -6 && x <= -2 * R2)
	{
		y = 0 - (sqrt((R1* R1)- ((x + 6) * (x + 6))));
	}
	else if (x > (-6) && x <= (-R1))
	{
		y = ((-R2 / 2) * (x + 6) / -2 * R2 + 6) + (R2 / 2);
	}

	else if (x > -2 * R2 && x <= 0)
	{
		y = sqrt(R2*R2 - (x + R2) * (x + R2));
	}
	else if (x > 0 && x <= 2 * R1)
	{
		y = -sqrt(R1 * R1 - (x - R1)*(x - R1));
	}
	else 
	{
		y = -R1 * (x - 2 * R1) / (2 * R1 + 1) - (2 * R1);
	}

	cout << endl;
	cout << "y = " << y << endl;
	cin.get();
	return 0;
}