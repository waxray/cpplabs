﻿#include <iostream>
#include <iomanip>
#include <time.h>

using namespace std;
void Create(int** a, const int rowCount, const int colCount, const int Low, const int High);
void Print(int** a, const int rowCount, const int colCount);
void exchange(int** a, const int colCount, const int rowCount);
int Min(int** a, const int colCount, const int rowCount);
int Max(int** a, const int colCount, const int rowCount);

int main()
{
	srand((unsigned)time(NULL));
	int rowCount;
	int colCount;
	int Low = 7;
	int High = 65;
	cout << "rowCount = "; cin >> rowCount;
	cout << "colCount = "; cin >> colCount;

	int** a = new int* [rowCount];
	for (int i = 0; i < rowCount; i++)
		a[i] = new int[colCount];
	Create(a, rowCount, colCount, Low, High);
	Print(a, rowCount, colCount);
	exchange(a, colCount, rowCount);
	Print(a, rowCount, colCount);


}
void exchange(int** a, const int rowCount, const int colCount)
{
	int min, max, jmin, jmax{};
	for (int i = 1; i < colCount; i++)
	{
		if (i % 2 != 0)
			jmax = Max(a, i, rowCount);
		max = a[i][jmax];
		jmin = Min(a, i, rowCount);
		min = a[i][jmin];
		a[i][jmax] = min;
		a[i][jmin] = max;
	}
}


void Create(int** a, const int rowCount, const int colCount, const int Low, const int High)
{
	for (int i = 0; i < rowCount; i++)
		for (int j = 0; j < colCount; j++)
			a[i][j] = Low + rand() % (High - Low + 1);
}
void Print(int** a, const int rowCount, const int colCount)
{
	cout << endl;
	for (int i = 0; i < rowCount; i++)
	{
		for (int j = 0; j < colCount; j++)
			cout << setw(4) << a[i][j];
		cout << endl;
	}
	cout << endl;
}

int Min(int** a, const int rowCount, const int colCount)
{
	int min = a[rowCount][0];
	int jmin = 0;
	for (int j = 0; j < colCount; j++)
	{
		if (a[rowCount][j] < min)
		{
			min = a[rowCount][j];
			jmin = j;
		}
	}
	return jmin;

}

int Max(int** a, const int rowCount, const int colCount)
{
	int max = a[rowCount][0];
	int jmax = 0;
	for (int j = 0; j < colCount; j++)
	{
		if (a[rowCount][j] > max)
		{
			max = a[rowCount][j];
			jmax = j;
		}
	}
	return jmax;

}