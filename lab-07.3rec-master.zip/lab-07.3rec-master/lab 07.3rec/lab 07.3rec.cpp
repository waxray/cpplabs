﻿#include <iostream>
#include <iomanip>
#include <time.h>
using namespace std;

void PrintRow(int** a, const int rowNo, const int colCount, int colNo)
{
	cout << setw(4) << a[rowNo][colNo];
	if (colNo < colCount - 1)
		PrintRow(a, rowNo, colCount, colNo + 1);
	else
		cout << endl;
}
void PrintRows(int** a, const int rowCount, const int colCount, int rowNo)
{
	PrintRow(a, rowNo, colCount, 0);
	if (rowNo < rowCount - 1)
		PrintRows(a, rowCount, colCount, rowNo + 1);
	else
		cout << endl;
}
void InputRow(int** a, const int rowNo, const int colCount, int colNo)
{
	cout << "a[" << rowNo << "][" << colNo << "] = ";
	cin >> a[rowNo][colNo];
	if (colNo < colCount - 1)
		InputRow(a, rowNo, colCount, colNo + 1);
	else
		cout << endl;
}
void InputRows(int** a, const int rowCount, const int colCount, int rowNo)
{
	InputRow(a, rowNo, colCount, 0);
	if (rowNo < rowCount - 1)
		InputRows(a, rowCount, colCount, rowNo + 1);
	else
		cout << endl;
}
void CreateRow(int** a, const int rowNo, const int colCount, const int Low, const int High, int colNo)
{
	a[rowNo][colNo] = Low + rand() % (High - Low + 1);
	if (colNo < colCount - 1)
		CreateRow(a, rowNo, colCount, Low, High, colNo + 1);
}
void CreateRows(int** a, const int rowCount, const int colCount, const int Low, const int High, int rowNo)
{
	CreateRow(a, rowNo, colCount, Low, High, 0);
	if (rowNo < rowCount - 1)
		CreateRows(a, rowCount, colCount, Low, High, rowNo + 1);
}

int Part1_ZeroCol(int** a, const int rowCount, bool& result, int colNo, int rowNo)
{
	if (a[rowNo][colNo] == 0)
	{
		result = true;

		return colNo;
	}
	else
		if (rowNo < rowCount - 1)
			Part1_ZeroCol(a, rowCount, result, colNo, rowNo + 1);
		else
			Part1_ZeroCol(a, rowCount, result, colNo + 1, rowNo);

}

int SumRow(int** a, const int n, const int colCount, int j, int S)
{
	if (a[n][j] < 0 && a[n][j] % 2 == 0)
		S += a[n][j];
	if (j < colCount - 1)
		return SumRow(a, n, colCount, j + 1, S);
	else
		return S;
}


void Change(int** a, const int row1, const int row2, const int colCount, int j)
{
	if (j < colCount)

	{
		int tmp;
		tmp = a[row1][j];
		a[row1][j] = a[row2][j];
		a[row2][j] = tmp;
	}
	if (j < colCount - 1)
		Change(a, row1, row2, colCount, j + 1);
}

void Sort(int** a, const int rowCount, const int colCount, int i, int j, int& k)
{ // метод обміну (бульбашки)
	if (SumRow(a, j, colCount, 0, 0) < SumRow(a, j + 1, colCount, 0, 0)) // якщо порушено порядок
	{ // - обмін елементів місцями

		Change(a, j, j + 1, colCount, 0);
		k = 1;

	}
	if (k == 0) // якщо обмінів - не було,
		return; // то припиняємо процес
	if (i < rowCount - 1) // i - лічильник ітерацій
	{
		k = 0; // показник, чи були обміни
		Sort(a, rowCount, colCount, i + 1, 0, k); // перехід до наступної ітерації
	}
}
void Sort1(int** a, const int rowCount, const int colCount)
{
	for (size_t i = 1; i < rowCount; i++)

		for (int j = 0; j < rowCount - i; j++)
			if (SumRow(a, j, colCount, 0, 0) < SumRow(a, j + 1, colCount, 0, 0))
			{
				Change(a, j, j + 1, colCount, 0);
			}


}

void Sort1(int** a, const int rowCount, const int colCount, int i, int j) // метод обміну (бульбашки)
{
	if (SumRow(a, j, colCount, 0, 0) < SumRow(a, j, colCount, 0, 0)) // якщо порушено порядок
	{
		Change(a, j, j + 1, colCount, 0);

	}
	if (j < rowCount - i - 1)
		Sort1(a, rowCount, colCount, i, j + 1);
	if (i < rowCount - 1)
		Sort1(a, rowCount, colCount, i + 1, j);
}

int main()
{
	int rowCount, colCount;
	cout << "rowCount = "; cin >> rowCount;
	cout << "colCount = "; cin >> colCount;
	int** a = new int* [rowCount];
	for (int i = 0; i < rowCount; i++)
		a[i] = new int[colCount];

	InputRows(a, rowCount, colCount, 0);
	PrintRows(a, rowCount, colCount, 0);


	bool result = false;
	Part1_ZeroCol(a, rowCount, result, 0, 0);

	if (result)
		cout << "col = " << Part1_ZeroCol(a, rowCount, result, 0, 0) << endl;
	else
		cout << "there are no zero elements" << endl;
	cout << endl;
	int k = 0;
	Sort(a, rowCount, colCount, 0, 0, k);
	PrintRows(a, rowCount, colCount, 0);
	for (int i = 0; i < rowCount; i++)
		delete[] a[i];
	delete[] a;
	return 0;
}